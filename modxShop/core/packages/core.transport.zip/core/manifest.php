<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fdf14302d3f85d086eaac6bba6a4a560',
      'native_key' => 'core',
      'filename' => 'modNamespace/1da0cf5819f7e9884d2c8471757a15fe.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '17e5dbc2fb7c8cbcbdb3553f85abf7ac',
      'native_key' => 1,
      'filename' => 'modWorkspace/1e11063955acff035ef2669e0dbf911a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'cd399697c47cd97d283919a9f3529713',
      'native_key' => 1,
      'filename' => 'modTransportProvider/792defa021c22c6803e055039ba97b6d.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '76c7479c4c0daf3d5702bfa8375206f5',
      'native_key' => 'topnav',
      'filename' => 'modMenu/d9bbc0467830eac7a9575cbcf673ed81.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f3d06de64c490d99f7ad375bcf2d656',
      'native_key' => 'usernav',
      'filename' => 'modMenu/afefae80cadeb12622e0b97d74e898f4.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a43c2e652b3b98bfef027053d9f9e139',
      'native_key' => 1,
      'filename' => 'modContentType/7bba60f81a84cfbd093eb74e537ba85b.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c2ca3fef169fa1bd7bbbf6321b2724b9',
      'native_key' => 2,
      'filename' => 'modContentType/07c0051be7f042e2eccc98562200c247.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c723f2d2ba8e27c991ac6e190e61e0f1',
      'native_key' => 3,
      'filename' => 'modContentType/43152c61b508cc9383813201f3abc75a.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b1b25dc172adfa71f11a274352c32e0f',
      'native_key' => 4,
      'filename' => 'modContentType/935cdf3c4ed0b682745281b84d49f205.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '400f4941bd88ac319cb1c83f21e89a85',
      'native_key' => 5,
      'filename' => 'modContentType/c3cc16f4517c4485d7bc6b170fdf4e27.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '475cefd805617737a92a1ce05bcfefbc',
      'native_key' => 6,
      'filename' => 'modContentType/f4cb259936b7df999d8831f210bcc98a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'efa95cd5b5f4eeada82a19a4c3d03363',
      'native_key' => 7,
      'filename' => 'modContentType/fe74c058c6fad81ac8d986fbf64e647c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9daaa1cc9b7a8fddd438d9b7607cf391',
      'native_key' => 8,
      'filename' => 'modContentType/24d3c4ee6b6f67f915dbb75f609b1158.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c989df252244859ddd243741df3d6cb7',
      'native_key' => NULL,
      'filename' => 'modClassMap/e0e78553733402624b0c6310ff52677e.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7723f8e4c8b63a3d2cac6eb8f9172658',
      'native_key' => NULL,
      'filename' => 'modClassMap/9a09783d13d338f3a6e74d888024f4dd.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3395cdeef26e4bb3fb511c377b4cc5a1',
      'native_key' => NULL,
      'filename' => 'modClassMap/5c3fab8a6770f470188bc16392524dcc.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '83bae738939ebd09161f5992dad3af4e',
      'native_key' => NULL,
      'filename' => 'modClassMap/77de336b49dbd4e4f3caefafb6eecb15.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '486a406ef5cd0c2e001870a3986f993f',
      'native_key' => NULL,
      'filename' => 'modClassMap/a8831c4fcadbb2a0cda7d20d1f51e718.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e76389bd736fa6939dcdfeb4bf47dd52',
      'native_key' => NULL,
      'filename' => 'modClassMap/41b8dce62c8519d6b6181dd8ba129893.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f124f595d3e82ab0ada7e952bc246423',
      'native_key' => NULL,
      'filename' => 'modClassMap/500bebdbcfd6536a2f219833fe55b37a.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9518e322376fb0274a8ec155fa4a5b3d',
      'native_key' => NULL,
      'filename' => 'modClassMap/2e83c866a44d5ed72b12e3a271b19193.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a775ecbf835ac660c0166cc73c36c40c',
      'native_key' => NULL,
      'filename' => 'modClassMap/4c5b7c6c2b7e70904078c4fd91f09006.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eaa557ae08493ae9d3b2261d3e2a231a',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/4cb77ed35e2fbb0d180c5e5c9f13b034.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2fa5a6009bc3b48727ff411a7def155',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d7015a017e3cbf621ed7bc82f3b6b45f.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '004075db78eff178df2f9d72bf6b7de9',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/8a3a8fd7cf13f3a1c90017b73f1c65cd.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9f38f23ef198b13cae35303e82bdca7',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/0cb0b9bb60ab57979c843ba10dbdeeec.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48fd0c1678318613f5f9c1cbbaa33fe1',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/27347fe2364091329412158fd4aed275.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '929009e8e2b1b360e553f1eadd8c3cf4',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/bef8a3acd60cd7dbf94a3015391c4ffd.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3038b1df071d6384c650e6801594224d',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/e0ed88371a95aee4c3210a91ed0baff6.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18351a4d4edf30425fbf54aba7e76e97',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/34ed5261b1bab64c488be6bd749216ed.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e584c7f5e48c3d7cf980e75ecaf7124',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/b55d8a6f27423e19729d80d75df8e68c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd225d4ae762737791997d335ef463f64',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/8d20e7833b2780f0f262a7e5b499bfb5.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8adcd9a938d187f358e3862a9e83b1c7',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/39149f7f9a03b80e3320e47db57fbe41.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '641d312e29aa53dbcdfd611b38b3e5c9',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/652650def4523b66b2f46d9988b7127f.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb5bb4633f805407c23c61babff7244d',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/bbc0cb4c14ae3342393a916e3b7a61f3.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38badd60d1a46730617f9e9896428d5f',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/cdb8127345bd8f213be2d656cfe45153.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0dca00ca4848caa3cc2449861dc7d805',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/c081304453f4b42ea4840beb336be211.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6195cfc1e0339b7c22dc6388bc571b4',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/2813f18cd9bdec1f2b92ac991112413f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4c3af38b9dcb164bc6c69c27249bae7',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/0d3cab4791d1480105bb4fb5d68e3352.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fab43b0a4fff1e2c71fbf1e425ac81a',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/85a2e49cb22c02f60fc97090699c5c87.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d8c63d5b832b267b6d2d3e40064760c',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/4bc625fb9036db71f80c89f5680c662f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '299c7ef4f6772be4b707a1e61e3d3660',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/688481d2580803a58d290bee3142c0dc.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49799d3d14b730f6c92f0f7f0c8bc54e',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/07f50005dbbe871d71c4e8cb27a8cd3a.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a68583ddeadec5966086a6ded28bc26',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/0a6745c90e9b189c81707525ba1180a8.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c37faf32d6d7539d6547f73784a49cb7',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/e677964a1a4cfedaf55ceb7a734e2dcf.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd181451e415e95e34f068a43a3b51072',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/b94505c207bd08b144b0cbc47d4875dd.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a17a1fd1d17b7658ae613dea3d70c24b',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/981c127c2505784eb667b3166da00f2a.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93a49f7de79bb0509ffc1d76c3d5f489',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/065b0d77c507a4e83292da209ec33d34.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05911098b4c42820d601bfe8a00ba480',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/d5ce859b6b779066118a21162ab5bee5.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4faca9f3f45c6e0dcbd2348aafe1ad4',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/c940f1afb3c01b8222a47d2cd6080d34.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b1d91e2026267aa71a3cc1a9c13ea21',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/33827ef5b559e31c8a2305a0362abd80.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e546b286cf9177e0005241dd64bccbde',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/d3d07698da1006de4c80cbbdf95c297a.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59051dd98ed87e98c809ee1640aa70ae',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/24682191e7f68c906b5e243a0729d2f7.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abb8a31f131435addd7cf8d170f806bf',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/8b2d33ff06e13e851bf9237a568c9ca5.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b596b3e033cf1603504be8abe92a20c5',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/bfdc1e835476ad4f94d63a812b921657.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e00006d78420009c8f8893bbb8ff2950',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/367d5726726e84d042afe2bff0e72625.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0658c516166bd84f3a2373e4b421e3f',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/ba3024a7945afa4a6d6d357a4bea832c.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23d68687d3c8345f2e0aacf0e989ee99',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/c7b561bef4afe3605ccb00bc2b8b6b51.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8557e8f21c7db23260dee2da47b371c7',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/6e26f0d42a3f26f4d0eab3bf759d0136.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28bcea1203f8cc1fb67d74d401cf46e1',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/9ec465484175575ea418bf3561048f2b.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7c080e00525980e10eaa324c99d38aa',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/69902d0c5177f45fe73164aab07af073.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0045eb43c2969994ddbd5ad0d0ecd4a',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/90141c442d67b6bb981b607f32f482fe.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66a6c4a0c516a5a751b81234300537f6',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/d31fd6eed1d667046bad087e0b97f479.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e521b4fcae7eb71b233530e560490171',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/5bf85f1b266a2bcfe1d35fd850105439.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b54e3418dd77d2ad63660a63c871bb',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/64856b317886fbc4c8c1e41d347cddd4.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb55fb5182e637a785f1dc4b28684360',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/1135d0651d2cfe45a310bb20078e1246.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82bafda1728085baca7b912e75d0bf2a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f647007776aed724e4decac32b6b2574.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e96a1775bd493c8ddd705b56b82f7868',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/5e43e2963e810dfc5a7948520edce34c.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '725b50dcadefe8d7c8097ac14529bb71',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/8672b1d71b95fad43ebdab6fc4b9753a.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23e236079bf511fac1a8b69041e96c38',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/bc3dab7e291792bfc82ddb5cd81fc506.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a765bffb8b8fbe9b64633dc8c141a9eb',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/fdbaa809854da6a65584a8bf44c978e7.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57a4496062fb147bbb93e82e729f7563',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/fc92f8dc0bb971f14d29680857ca1898.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d4981084153a6a4b73acace4b82612e',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/cbc62bec41df4f07ba0b02459853ab42.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12686068f8cf57faefca9cfd793d03f4',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/70465cd8da97a9f8c8adf48188e4c75e.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e9ee14fdbb570d14ad47a6f9e6567e2',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/4ff6783383651bb64b8ab26157b19b23.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47a93ed8e97185c083f7075a873a5855',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/19cbd09b5e245488c8d2896068e1b067.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9e645218bccd6bbbb21abfe0a445cba',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/d53713a1c034190ba092fbb5ef4bba4f.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd74ce587e1ea50912878fabe8e236c7',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/28eb7f896a751abbbf1161dadb386f04.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '107d6092ad7c192fe1dac1b547d4701c',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/cd37a2635b44ad6d64c77becd4feb6b6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f342843ad46fc3ada3e7af6181277407',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/ca378a213db2377694259e3380a8491a.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4211a870a77b754d2785044d5934a04',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/493d552c378ac20e211a4514ca3b8299.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '218bb4b77f926ea107012d7be9477eb0',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/70395d88ac232649ef42f0a1eff806a3.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cfd198f85e7b5ed88089ae87eba7818',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/7de140bf1532709aaf3a21b915d6023d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b93ce7d51a4bf8a4e00a6f5bd5b671e0',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/ce96a15875ceced031dd4a7e8aeb10c1.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e54131be7168b4e65c572c7571776812',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/474fa3a5c29d3c264905ceb8b67465d1.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a3f01f8a6b6d4dde32985f84b5f2973',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/906940483c4a84032eb689ee168ca0ff.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84d2bd3c03f2a934e3a6dbe4734f93c1',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/bf0b85a838eb0cb7d38fde8738ccf8cc.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b31ac3a3098fbbdbe8c3da8ea5c98610',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/5e3d09d2d04fb292173b816cffeb4251.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '661aaea7a918f550055ef5ff8445c3cd',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/4fae63fc0a76e87af4eeac87ad1071ed.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f902a379cc52196add82f750af4946c5',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/2d57432b3f6880d0ba55fddd46a6b6f9.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cbefb28d032744afff4d0161cf48c4a',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/9202cd8282e86c2810fb06857e0fc447.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aebf2e61fbb91f01efa1d3690123737',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/0334924dced547fa8aeb84b645759659.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0a0d99393244ecfa48e8c069b50fd06',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/f0f205cb97ef0ddde66f4f8b0508f28f.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0be21a743bd47a133d29a1943317069b',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/35c5f5e2a223c01f50acaced707b811f.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c4e71964bd5ea91a1ec425e2abf2e81',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/d1a323ede870bf6cad294f010364d5bc.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74f12f1c1f58260f512ef1cd331f113b',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/0bd5569d4636d157d716881b4ae1ce90.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83c030ec69772dc1deb71607ce14c3ff',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/660780e99d80969557cfac0d12f7f3a7.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c8a4bb46611f8af1df6cd39825e3f25',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/e1c1012caa8fc8cf5178bcb561b2e173.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1086b86719d2f02929e337a23f679b9e',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/0c8ccf77fd2be74ba66473ed63413921.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1f5192a2f29c3b35045302bcd7a52a8',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/bf52f56597572808e5984c5cafe6e49a.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e835178b380e28d6131cd7aaedacd3f',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/ac227bf2101de76384c45b35904b8abc.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5566ccc4b3371c76699cd339a835a79a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/3f6490c25ac3c91509e07097e6230776.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c5a63b01e2f1d6a1320bb66ad285ef5',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/f26302c6697ac090ef6069a91584c9ec.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e61674e5f6046a2a54d0770af2b6664',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/bc3ae2fe669f7543d30fd5d099a12c33.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c08c480fd94496726243198c6fc0bfd2',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/fde3ef0c37971adc4177b7c2fc2e8030.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8896ade95737e2370d085dd06e95a35',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/4148994b5762987707016331ec248a35.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd917d58aba6ad50187ee9d4378f1eec',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/2100bdaaba610614c9f85475382a838e.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f6fe9d83e2373784c331a6797f56c06',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/456a16b579173155f0725e750baa6f59.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cdd3b11a7f2b4ef0657a0e77e146d62',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/5676f8b61e12ef9a81a5119ed63ec494.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49d592c03c30f3156669fa2907cffe09',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/838cb1fc2fbe8d6130e7c6c29a96918e.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '213068767eeb7e744ca091525257aeb0',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/45136f8e3f7d443fc5a09714b8fba030.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55cc7ab5b44cd0ac810cbc4cfdd30fed',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/373879a929e439a8a9890cc2fe780009.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07b239038766318fee696b398caf236a',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/85a63d263c5ae587656b504b749bd9c2.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d3329b8e04df07f762219898c66a2df',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/49de07cf0a8cb56c01f303ab74d72d52.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d6a1bc3d5c7944dec779e747f13fba4',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/003a91b07b94672a216c2c9e2f8b027f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9af0b917fbe87471ed64b3079a3e620',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/fe4cfbde9e2b7342f51eb7c3f70112c8.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80d304a55cb0c57281cee6da6189c1a2',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/e4ffe47324b428ea69bb351827e03602.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0150ff975d227295c1566e6f9419da88',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/6a176897dd6bccf632fb9838dfbfa511.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29d901c0078ec52c9f0d3d1e30d80ba1',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/4b9407d30627ed1be99ed7d55e1940b1.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f19ea73c37503a2867a4fb14321a7970',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/7437cdd64162a6b8da9229570563bbe5.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16120a6fdb6145201e864f4124bcf90c',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/d7c01bd3686c597da4abe14918c6b7fa.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfbad3874072ff16a8e6c0daac279a01',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/4d98e15c21e6edfcc5055f2bc6d30a09.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73d209e960d01970c8b71782f2e1e15b',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/312c21054cd987585c21c74bbf843372.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd788cb922b63770d783c8e8b6ad94992',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/d64f121f33cba71140f5734c8692b019.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d6fd2e2749dac6e8ff55d4402c808f8',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/81f30a505d966787a1c6d2bda86bcee0.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e84e1e37771626403fbad9ce86833c4a',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/c9db5804dc474bb12d7e81494f58d64b.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '829b97a73f2fc7af80ba42c1ce271fee',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/c6417a22da1a1cc42e4cc62fa8356c0c.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbf9db66611093a5ee6e13cf7877564d',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/663fad2fb8804b5108323365cdbe894c.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c19947878cf7434fc1b74901f656a074',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/0b551bc89c5ea248966de6bbd5368ddd.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df21998a63ea5d1e112e6498864922d1',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/2abd411b6bdda461dab61b2679ca62f3.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a4f5ea95d261a26c48db9d438970524',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/cc48a6e4d0c72ae6ef2ddca5ef583686.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0144500340f83e8abd69bb8e03ab769a',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/9978bcefc8c187711bfa167761cf78be.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40f5a2d09d8f72a419dc59dfdfb3921f',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/e170a6f6c597ec2cb07ab8acd65cafe1.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '104793875d64b457ebb3c91a5e5c25c1',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/cfc2a067eacd2a9317be45fa9a7bc71f.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c31aea8c95ba1a656356da2d258c2b55',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/ada3684a5543f4832cabf3bc2354be39.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '194fd378fcb94f646bed9daded4ec35b',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/1fb0da43c6a9b5123bb86dd1cbb073d8.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d251b892bfa034e40c5de396bb81fa8',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/1ae4ff5ab0630e2966932bed69d04bc7.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af2c2df793be64d2964a2abde156a86a',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/6e139076ada5bd7c0c153efe184a60d4.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0601407cb9a92f005029cce3182c0c19',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/76fd383cd2b9e14c76e90b2a1f3de185.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dd90d041a4d0e053e3d51076e719b9a',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/36d8208e63d5ab58326a83fbe9cbe8e6.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12139861637f43626971f4f55bfe8e74',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/e8388984b277b6eebbe5b27aedadf017.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd58161fb2105a2ed86fb4d10d0f7d69e',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/2ce986f48084519161525db46c3e5ed2.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84a9554d8fa1f00f3d22ee6ac3659f01',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/dc94d446491849153484fbe1285d97e0.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c507e221d674c8f61ced7436d101f780',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/b3ca9fd2a8267302e6e883c7cc86a098.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '571ba6c7df4009fd8a999b781979b289',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/9ae4c6662b6ff19f54ed264578105b03.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b0e9f2e04e4c48f91b87bf08dc834b1',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/49321bc18b1723fa634fd3663fe3aea3.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b46391a67bacba8c59fe9689403ddc5',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/7ac132145b66da97595b38edb2c969f6.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1009e4290bcb072984a43e7459e3d3ae',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/afba9ab1cd58abf9cfa8356cc7eb1ef5.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '370083ef03819d6daa0fb6be98cb5f27',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/ba37205505ee04a03d0a5e2913314306.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6e66734e5845134a6127d54eb610466',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/d80017e2f7b0cda780d671432e876f26.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f91c5e4ac2b0487915246bb308c26195',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/9e7a4838a0ac81edb81a9ce0fe79728f.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37644d8894a74226226a5b3829fc2084',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/a4e3a5f7e8dd37d765c6d6e3d8aeea32.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '125b323248686ed30ed32149e0bb8681',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/6bc44a00c875cfbfbfe2c7a753ffd5d5.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db7f01be05a929e9c1c430e562ebdb0e',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/49a54386cd952dfc8a5e98f1893d6fd1.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f361227e2ff74789d574bc98a66c1a43',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/033e63cee2bd2b2962311cc63b514bff.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d6c6f951e07f959b4be1e322a74c9e5',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/59140b3fcc1afc17610a7ce706ebec93.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27c360a25e53ec839b330c25120fe073',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/1a3256fb3135d715853e830286f0e237.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '695d509e7848bc655bd11c4a3a0045d1',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/34aac3f64d29485f82fefac54357a97b.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '573425790d7134dfdc3a6018a7393523',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/101160213c8de3b126c506d7911dee77.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41a5a739ce86823dc86fe84bb9d32ff3',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/7bb90f067a9893bdf7fcc9d619514989.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '622cf23058d69c982900b4098b077f71',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/f3fc5edb3e8a67efdf327c8feca97e52.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '780fb349e79a46c64afc38ad2244c2e0',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/c0b50e3d5d23cf0c79c5fbc8d86efd66.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '474f30632125ab2a04ef02036797da78',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/bc36e190a856c845c08de6dffcbc2051.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '340404bead280c403dbeb77581cce6b7',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/6f4ec014946ecca75ea1b4a06afc2547.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa7320146aedde312e300a949b12267a',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/1d75a0198a934777007055e925388091.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '807e653a6a3c613f7ed0465bc90ae0bb',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/766474a4ad1df452a1fef6a04651f701.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '237050e0196088a8659792f455c3f93a',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/55a6791d0c34e03de4dd1993205d8d46.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffee0936ed49d1acfb6ada07f568c756',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/dfd618562e04b53272ce9e37e42ee80b.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd906b616b68fe2add0e3ad3013fa8b06',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/74fb251fc64c5a56c18ad72d1a8df45f.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b14bf207811c0ae91d2138a9bbf66aa',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/35a07c062183baa5411e4f9e5088b722.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca749114908de2e3bdaeba18e401f5ce',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/da89be8b2d56fb0b280f9e7dd0b3d3c9.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f579927a9b9eedf5b69a9f3a4d64af86',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/81c726b12e32967f36bef5d91721a861.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98da85b302589e7db14f7a07ebc0cc8f',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/df9ece9497b29b8fc33a6959f1bd8032.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2e19b6ac92316cb6efc4547ff21b150',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/0dcb6993c533309bc7b0fa839e20b9ef.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b8508e5238ab1727a1e460708573811',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/65f40693fefd9bcd151290113449bf5a.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdef00246094d37a6b2aa7a8655653eb',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/14751a45d358f1b61450c6462a9bce40.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8f3b32306da80ea0f10f4744f86d8e4',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/3b3c16232e4418dc9619f7e730096c55.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5007e25c531545e64cfc7d772203bf23',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/ca70c474a800f5472f4fb96dca6d2c86.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d6b1ac528432df8701a0dbcb7824d69',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/1bd16ecbd85b6a527cf344bb84898111.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba6623bc58fff8e60eee3f5792942d99',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/70e806c324e560843aa6658cea4179b7.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df1f9e468b075efab0b1b01017d33466',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/b5876c3fcc9a17b0bdc5c711c0bf706b.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2acfbb21876661450c79ebe6a0527b51',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/4ed7adc958a4ba00b38feeb3a129f217.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2fab74602a6a9105e14fbec9057f097',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/393eb3f6659e9fc2bb08d80b0ac5f750.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a88c83f50e7fe1b5a9f915cd2e24087a',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/1fee10b323b8eb189125616b25f2494e.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28f0060356273ef754b649aca1da522b',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/ee79f8458a698283083246e4aa806dbe.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b8a3f650194fc5c83b82e1f858b03a6',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/2c8c4706569183040341ee457cc780bf.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cdd5c48e31462560d26d0152fc7ff59',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/bde79a0bc368a7e3a244e77931501890.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1f319a601219404dc03856413fd6646',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/d598311095c66f871ce027ba11a3f9ad.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bddaf578a518e110769f10ca73dbce4',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/190bd8fc2f2058ede92a4695e5e39de6.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fc7d761f67b1c8ba5443df8a86f42f9',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/d6b317b83aafd5612e7daf7a2cd93faf.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba0d636ec3f9e696298e224c4dde8f32',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/c00030a130116a38b8f2d697473ba1ac.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '914378bee7afcad6738448ccbdf35fab',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/402b03d2dade1929f41b7d85f7bcdcbe.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4be56439e1aec355a363118b71fa6703',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/18a94345dc28d5d41d3d304f3c3ff9dd.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38ce2ad47b3052fa33c8921a350d7c41',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/679dcc133ca1f1f560f543cdd30b6526.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61c887ce4a3b4f15eef7fbabbcf27c48',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/397e55f3fb2c226a283cbdccf501fe2c.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ef2e631304e13f0a54570315f8b1a90',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/3c7048b43c16a3877fcb13772848295d.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bd832a9672b2f4b0bac215857b9da12',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/bf76ea0c2d2f4d6d18b0363a9c209548.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d33edcccdae20700c9a1df5d4a32de1',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/2d69f020c0392415cecf1c502ce8cc1a.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a37be767bafe921c5febcd3da85b68c4',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/5e49b5ec0e3ac16237d812a3ee7ecc48.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '763084a51aa183dd1b0e0d70159ff48a',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/08b28950fb5baf6052c20d96e64d0007.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb69411ab45f672afd3a7cd14e96912',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/02e9df1ce237da662355837613bdc8c3.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e172328fde5e1ea87a8e763fd1b2070',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/0b32c43f3c2cc9c2644d9ce3c150c98f.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e9caf41dfffc18892634bb36dd48da8',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/5e1376a1c84319ad90e271b607246eba.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f7edcdf6bea7f68373dc5531e7fa5f',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/a2be8adc5d6548ac2e978b5d36958e42.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1968f37661d003348765b5af1c04b5ca',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/3ad2964b4153a77604343fe2b74c46ef.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '791060c7353721057381beed7ffffbff',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/796ddb4b888329090e15f890eaee27e0.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28d8b3c5c4053f1d960cec2738ac156c',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/6183cbd089d11c06c7eff59c40e3cfaf.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bd8fb7737db5b8508872de7b0ed632a',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/a6a7f12e0f7b94c4cf58f249b44edfd7.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f65209ba3082c66bd7696aae47b059',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/687927a7c621692244c1b5ba9ea0f46d.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f953d033a07d12af6eb4c31c7c4c9afe',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/6a15df23da671908cec47799b2cfc398.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1073409c16a54472aa755c6ae5afe992',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/448250614e01ab89299cb6849107fedc.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f128a3b59272eae10a994ed8632d0c33',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/89f696aac30a10c5fa5aa080592d400d.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b67ca4639520c8d06f49f426f01b33b8',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/842244feb84b919cc813308c4c025514.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '382fadd7ffb5c7793a4ff656e11027b0',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/9edbbd05951aa03cf6880ed3bcbff1a8.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0441989d6fb305746172add4f626ba50',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/aff571f37487cb4956eec2d75ab0952d.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc907f5990f6236749f7226ff2964a1b',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/0fbac6cba040685ed6873b62f1152a33.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80803735dad6318c6d4ffe7b44617a6d',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/7fcea9f12035545f87e65756e9ee6b2b.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5681fc86be473d8c51829b88141d7ad',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/aaa76b3cb32bb440f9403283d8376cb2.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b840331c976393721ba2f9898651787',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/f2257a2d358915729b4eba160f580619.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a28b6f240eeef26a0e93ea936259d107',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/9be0ce2cbec57942cadea0f82288eb2c.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6afc77a0752a3c00eddd899c47a9100',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/ec00f3fde55a4a76ec007a827d5eabb5.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f26d661f46344bcb36baddafa9195f5',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/6d6c9760fe80038b519aeae12c110b4d.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbe6e3e825e51b0e4f4b3cd65677343d',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/2c4e66fa3d2452cee05b88d8c4e4d35f.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01f66fb59de5bb95848534afb86d4dd7',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/6e094a71d032531e09114e328ed8fe26.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cf0940d0beb608cd6d5d087f8f84524',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/3a6ebd9f3a73d8c727d7e427d92d012d.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aecc937af76447a6169ddd47b9cdc25a',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/e0132f5a241532ddf5addad727afea62.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5497c475b94b5147ad4a17d12187bc13',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/4c4d06c3f3d1ba6cc435913238a85b70.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7887b1ad5871faca731719687ffd66c',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/98265c5ab13bf9e2ad5b2146d785d569.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ce698c71ec20e4761273679ffcb25a7',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/8a4969eee561b90c06281189a8a9aef6.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '297dacb5e2138a4f89013f9cd61c0b4a',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/da5f6004f24f69cb844ca146e01baa35.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4555e0548c1a76925e3159be6f3e6a4',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/01dd234664358f7fae0b0c1486208aea.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f15ae6c69021eccb03222134a7d7cbb2',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/dd6d29274b0faa01bc2c478a33df987f.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '662ca156a2c0c3a4c176df7bc788dc38',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/f60e6a0a0b074336a9753d9158fdfdf8.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc309faf392067fb497a50123d86671d',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/4d968fe5d16225f4c4f3c54e68093940.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d7b26e219c1e680047861cd46f6bd05',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/aae93919cfd9bc60b2ef2973140e16ab.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '331db1520a2aea8d43b213691e595d6e',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/d365946cb5619bf50bb02c638a47513c.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5370e8d096aa15f7815cd6a9876389e',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/556fbc811da867ab41abbf2085fec3d4.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd56ebb9a4c2939428c5316badc03c70e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/a8606234e03185d125c71a41ca17d26c.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48c5df4413eb5b7b0081760d4d6bcf98',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/64ca0c9523375db5f5fe06f4a8c1a244.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1fdae6f619714f6ec0ab02cedde6c78',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/4c5a80225c3b8d50fc60d375a5e5a1d7.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bdbde0aa368481bb89dabf856d01576',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/4d3dadc651890e7d28a9a85503dbb413.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b35c420996fddc3299de3ff9e036e958',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/14ab94793886844e5f1892b214fc9b62.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '177d259140ab7aeab745ef800cffb20d',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/7c19fda01e494704670ca706c16621a3.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '037c38d066edb802bfd8093697a1cc85',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/0de4d897c50bb48a4e17acb21e7faf87.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27f2f0ac64ffff7de7b47dc948712ddc',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/aeb84d2ebcf45e3b1630f4148df12c68.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8d8c7029f8f5f63e43ba71d44106f23',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/af2b0cd4c58b9ac513631a0a24756b4f.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a491d5b8177f815be779e25f4dd23810',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/56431e8a6c05f4aada5ffa0beb39374c.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a1beaa5c18b3f583983253ab3512930',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/f34ac9f7c9cf820b0d17b17969cc6203.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40c741c3ce06f5ee2271d8829af15ed7',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/2126bd49ff8e76d2cb70eafd0f29006a.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6940d7cd9e04011d533494485a3c8970',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/5f8d155b9ef768d3bd10ea3502201dae.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '530ef48dccfc21d807f21034042e3ba5',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/f828efbea4448ca6b310474fff99c1f0.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a78b20dc912cda2ffc3745e2a3bae60',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/139757714eb342b63b61a6efe7771291.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '948ae7d75ce9ae5a87e1303a5cda70d3',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/659f5661503d147ce152d75e18f98818.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e0139a78f28723b50021d97efb1c45',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/9366fa0eb2b14d7741ed98f70baa0200.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2962c6e64f97fc0fe6738e5d2516daec',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/061bf13cdfabaab8dec9b8529792e3c1.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a840b761ecaed5aad3b28c2c1bf28dd7',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/4f5cf13d46b84ab9af23d107ec48c9fc.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a27b29c06af7ddf5a0283896e231764c',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9fd659c7a7671fda1a797d302c74b08d.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae7f8d8f2cbc0b3175eb67473de174f1',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/677f304c30f2b4803a96477d8654e69a.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8801dfb71ae93a59a3e6b3fb01e95156',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/b86e680eebf9f162cc337d4e692123ea.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd435bb297acd5a1419d93a7ff4be952c',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/73dd879e4df38f5a801c87677e613b58.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c6c9fc2eb0efdc1b61c2899cf28ef22',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/245a188b447ec1792af05676c0de6aa2.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b6559cd4e6987960716e12da60dae00',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/006c6ac500106dcfd375a04cc1fd348f.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c861238c341d66700e79a23eae3e629',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/9939791dacde07a7229d7f81b48c44f5.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24e71a167a72fcdebd5886268f18b44b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/c4ec204ab6168a207b7ae763239a3b35.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b75be66f15c594e93ecefaa56739b4b',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/77c9d79169262039d0b97a16ce2dae3c.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efb18b31fde2ac4c57fa1715f7fae2c7',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/8993814163011222366ae010c3fe1bba.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcf3db77557025bfc0d1f05c2f24f2eb',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/399319f189428504fbf9f0b62200b67a.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63966ce27057013f11416c1aa504b33c',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/ab76125f32a3a882e1ebd0fc3a34f949.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '421904117791f11e2762d7cc11d82df4',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/a62366c65366398d47c4a0880c9ecc9c.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eda6bd18b70428e5699267ab3742460b',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/ac484b0c87a9b2cb2f3d2f80b4f122c4.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '241a113c7f1a412321ca1c2b2efa9533',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/87e153a1b78bc4081ab4cd591005ae68.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dbc2ffb9450c6d89f223fc4cc0f6b17',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c41eb1d0b74212a57435b36ce3c84dcb.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dd255eff4f93a343938996818c959d5',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/2d32bd4334a5b8bff12e6f1329a856cc.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fccdbc60cdd987dc6ed4663d5efaf4e6',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/46b273c3f351195be453a5b00081c6f5.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71169b74e902ff5af3f8ee6f5158294c',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/bf7f156efa15f39f9601d9f17327f46e.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b00140d0e3df4875d2e59b533c1c9bb0',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/e37689e72bcde39fd0b8cf3d638122ea.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ab251c21f38b4f72408d3567974774',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/f4fd9cd080de67e6a27819b9bc151ec8.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75885cbc547bec6ac78665be76c114e0',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/d864b7cc1c073b07c8aac15e0e95e9c7.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49e6e6ced7c535aaa642fe644cc90890',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/a8b05bec49c34f67ea45daef417f2a10.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b27b2ad7ed7ff3750287619bb65aff8',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/3ab6190cd99e45447ea3da5afa4324ad.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62f701319a41d006286a5bca52138a37',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/92c089141bd1e9942b6ea9dc2203c6c8.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a8dc611de46c2924f0bc3a73c924809',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/6e5d949cf90160a6403c1767d5f09ddb.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c606956b9b3c2e0a3f260361152910b2',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/9f831e5abe1bb87fc4cf4e4fafc917f7.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2088a1f61626643b15f93ac2b2c9517e',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/bb4c636b754480da69c5f1af194194ee.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29d3b24a2b07a8c0b3d3011d94c6028b',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/4bf27d461b42eea0bd9f33afc64c089b.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '154eebc8624728f2d2b871e3a4f54054',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/c4bd626e7814991d77183ce05daad918.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7100abe0cf37207dc766528e884f107',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/c930b39d4662e2f9758b5eda68894f1f.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcc0902f971a2d73e79cb5b52d06636b',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/81d65bdc49935ba36fcfdeb298cc6945.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79630de4a11f4d26fdcaaf88d05bcd8e',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/920e7351b220a47d42dad4c2af9892a5.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a65390311c825c3eb81fee3a6fd8a8f',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/a18216e1fbc0a414812102355e10c91f.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a14198f694c5852fecfc277eff4ca468',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/cbb155e4d7b9b34ac066242e76dd1c8f.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afcadd130c9292bd024a81b67d6d3d9a',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/fd73dc0b6951496e9b3d970ad29518a1.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e65d1c21b8c97673ffd35c3382da565',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/860f25e0b280d3474b6cd6850adafc16.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2da6a077de63667755fa14c1d1456336',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/95dc87a6b0839e2b3f1d8a00c38b0447.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd092aefbf581f19edacd7ee0f014d09c',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/4df8e202dc6b21755d584d5271e321f5.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '387892778c028374098f100773e518f0',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/e7b6380daf7c9bddb72725116289d4ce.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1eeeb96c92ac6765684cd4829f53894',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/112d86a25d919202dae641813427cdab.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8beaaf5fc898a8ff2d5b72f5bd87bb4',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/44a044facd3b9170f258fb0e8e1be911.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42e93c9d2cdc25c2de678769501592e8',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/133a8f29947743103bbce6bbad4f329b.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c91451d916505c998faa1ad544f578e',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/c7ee86101bc853f96558c5eeb247fada.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a833982e844ba91a1c266575b3620808',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/b60cb517db0951df1b5926841421f1ba.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80e7d676c783767634e3ad21d4b19658',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/7115f3b7c757644a4e6eb960e5a8d021.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd57f98d7de0ab0631acfb19c649f9194',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/42d731d1bbf4037952eaa90d9d648035.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a643f392a0eca7bcce86b3f54ec8c5',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/f4a0d9648818752bcb9a9114195d6d1e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '172f54aa26cad99dc9cb6ae5191976df',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/cf914acf5ec9c63c965b4eae37839a41.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25693cf437d3872619651d8876e41022',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b68edfab81e633cc5ab6b76e1eebc043.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee5899681d651b5be5fbc4b3baabfae4',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/2ce4aadda5008ee2a92728adba861ad1.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d2cc155d54195fd61babac5410416c0',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/d08ec5c372726cf71fbfb1c923b4edc0.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed203359c62e96f0f8c097d558ace8bd',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/5f7d74bda92ce7e777da1f6fa6465a94.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53db26b4a40ccbf88885786858f4ae3e',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8f7094400cf5a4aaf891e368a400fedd.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf295c6c91f60558c195ab85a80711ec',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/4c8950f0b8b606d2de03f7b493c9a3e7.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '488b2691718c79c4ef48bca2514ec000',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e7f6aa64ea404048461838cdd783b1d4.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ad4b9ff777226fee43224be80894e16',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/fc38a39e797cdbef800aa03bd9029e50.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fb77cbb86969254d56ffe5f1359d02f',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/8e3d17aa38c2997d033bd0da362d52b3.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1703c04a6679299ba81642e57778539d',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/f4d4d9183529bea3dc5186534d08e010.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40c1a619997f927da108938dc39ffbbc',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/cdcdc06e5159fd05fb869dc8709e7e5c.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5cdb4d1237bdba1bb331150ab81fa73',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/abd3fdb3d9f6c19b700949eddf0cf334.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89dfbfbec42050e81498af3a02df7f2',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/f07cef0ce68eb860bbfa7fc7577e9c2e.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bde1c60e9e9c54a27d88b0cddcc5af9',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/a909f2825dd82cbb981dc8d1b5901f03.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fac8bed3def0a98aedefb1d38f64ed52',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/ecf386e6fdd9f813cb691ea3d703fd95.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd53956a2f63459d8aec9b881c1a814fa',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/8166aff46839e8712b1c756f09e310a2.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27275f3e27317cd375562d7827845576',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/9361f27dbaa145d6739daa02d94e622d.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bcea278114faff253b06e4826704ec9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/ecc9bb2daa2d89eded24ca83b6d6095e.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1264e71c5f59862aceb94650fd40f04b',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/210420b426d69ebc87cf0b359cfa5080.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e10107f628e8fc68da306dcff69c42be',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/8bdefcd046f0834d94e7539e8864aaf6.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed32eb3977a69aa6b7523bde66b50d5f',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/6f9d5c48e5bad60a340ac12c175ee548.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0931e3955a1f36a0e3ecc6656f02c0',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/9458b510648d15c0451636a36dc1b3d0.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a902824f66ad4708f608e116329c9b6c',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/7fd15dabeb3cddd46214507d565a9eec.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3ed6d8a9da5a6ad1bfc34db644e0327',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/54292a4c17232b0b2e1ef1f8f3189a58.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82cb24e5cfef2d82629c6e6a8239d1d5',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/885545437e7382c9b25472bb1594bc2f.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5ba93084db6fd6eba309007e0a1ca55',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/61fd2ab41c6eb4d0d94d5ece628b7a6b.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28191d44570cff00e2c2f72032ce1b9d',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/7c7694f0699cd5288aaf8c9d3c748a2a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '920e7a3ac742277a6d14fb69dca5b832',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/5f5be34e830d1fd2809bed36f8d02d00.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9230be9aa1f3fa96ae4f8c373b10e9e',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/c06c0a73ed02495a259c56ddb9dc5149.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdd3776464815a637d49b18fe8de1abf',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/5ece5a6f61b28ae89ac75673d51cbc2b.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4286638495f4886c01de4675d322028',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/afe33032ed460e2073731921743801cf.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67ff37e7c08b4f87a7b609f3d6a002dd',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/987ad42492932c059758aaf1a2adb958.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9632ec38ea66a601313b0b377b2973db',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/d95d0c1614955691f9455c14a2877d53.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d9f75e9bdf5022f7a02990d4bac460f',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/4046e06300901d0a005c402d30eb3c1e.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '533339c0df83d4e74a4d76e62fbc4d87',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/c6e1d0d237251b508e62b9cc651d00fd.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f31a3ea35624183170e5dbd541346196',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/f5ef8dcd86ab5e3b1ebd1fda888e887c.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a1f166844361292d18127215a1a1565',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/71dc6da533e8074eda72c830a52fba48.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb22b8747d7c675e259d27a4f7e3da1c',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/a861a5b15dcbfb91a163c1107c31529f.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e688b1c6f57565f66f93048984a520b',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/473adedbc7c59328da54c55e7c4e664a.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e7ca2b62664d67e9c83ddb550838f61',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/560ef1d6b322f291e86e92fdd0c8043d.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1de00bd0ceb9b1966a190e34b17f1cb',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/d4778d74678cc0097e8f0c7087e5d26b.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a3e4e64aca2be7f6834194a6a60f0d4',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/b6962d9221e4dae35598b0cb99c8169a.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86ac24272fa9708a022dfa5c3344faed',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/948f441a9b787f5c953bdd434ec569e6.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8848520a3b0244d8d04a6d5be56989d',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/e96f505f5121dd2722a509162a2a4ee6.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5fa8a118af2e2a61e65dfc3f0fb6ad',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/7ac515901cfd3a060b40462319c35f25.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59cccbb70b4e97f7ee08a53ea90399e2',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/972af79c180e5a8cb2a68f81008a91da.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ba792e1681cc45bf956bc2028d5b808',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/6dab2b35c51104985d21038e66ad5309.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e3dea3d3b8de979ea06d94ba4a15b3',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/89d07dba646f0c7f2434b3f4da8bb36c.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8fcb6bf840386064e6509aeadb14656',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/5a641e229368b878bdf93f76b8388789.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '505d34032608cc366224195a0fceadd3',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/f7aa5b819f328ea1d64c4efc3b4bdc22.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea27f9c3ef57ac6fda11e0fcc51a31f1',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/64561ca3ca2275688271815d3fb12bbd.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e03348d1408c4ea7263b9d32630be9b9',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/e32328a39a3fbd8fcbdac354389818a3.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90210f0199b1a5045967245965c3ce0e',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/0febe52c26e3c3010fd4b07283249598.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c687d059158efb2b0412197a3ad83d5',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/d6addf1164951173e4b06cea96051693.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c22afe826a7f05574c4a6c5b533488e',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/f5826ddc9ac9777ca22cafa8ab82fb85.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74c77a23ae2a7aadd2dbb98ad14707d8',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/650be72a2dbfba53a166b51029e02f5e.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ce5a43fec4880aaf81b6be3285edbe7',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/0d182ff58be2ba3007c309a4017c266e.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '310eec6c0c50dfed99fe01f314def054',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/0203c82ae879d787678b19f447bd833e.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45ba8b4422e5f6b703d37842eea4700a',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/edd426dec7701970fee5847f243330be.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0a8cb37ca6d840f38efc99bbff198ec',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/47b24d638d8b2f8e2be0f0477119ccfc.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2fbdd1f5cf7e3a7d86918a89cfe7bc1',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/72f883478693b030dc276f25bfc3f159.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '536f16331cde66692d83af120970c840',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/59c016f63022520627848eb5dc9eb06b.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c22e5c811a32e14df1a2509b248ead81',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/0b7b9390884a83375c626e95d2776a89.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b781b748ff1afc3d604c9a4056986c63',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/755b27396e2f981b7d2148028e274b72.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ba135763ee41fbd949d1741d49268c7',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/0b57b37a754876f8da6cd61d128bb3fd.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '564fec744f395284a9720fe9c480248c',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/4b94c7afd6eb756e7666eeed58cc846a.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d9ae43491af5c9c31a61fffbfe9e3c7',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/d5bd20fbb398368a6a4547084ffb387b.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07dd1a06c5405602a21d7cb886ef73a3',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/1026bf5b47428386618918b4c6de3251.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e75482ef7763f833155d493c85638041',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/c9685d4c0ea69b24b4944a9a2b338ba0.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '483d57467b4b78660d9dfd6d73f109b3',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/8ff46a04d5181ed63af8af1c21d533b8.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a2c79f179f84abcfce83eb9aafbb6f8',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/93219970aba69d148b1109e5fe3abaa4.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dda99efa8406a2c2eae3ceee3f11048',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/12ac731bdd5b56c8d53aca1bb9173c3a.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdfb99af88514b23ea67faa1910b5047',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/ff9a84ac34482f952b765ba990928b8a.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66f82e6a5788ebae0cc9b23effb2235b',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/fa36c32d6e29bff229615d75188cd0c8.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9f40a3fb94340c6bcaa864262608830',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/d335687de4faeaf8f96d497be562b03e.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed20937926d698935e61ae773d5f4d88',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/4c675b90e62954ab5fecd0bbfd4d3992.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c8e26d93ba25a8702a5d3ea77e6e9e4',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/082ca64e072fc093e9ac8e1a30846489.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48a22769659a8c9dbd182430a7856a5d',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/2b727d4ae4e60ab24e6666e7b86afe93.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83d829777e80701506dd92dba21594e',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/379c3a45c74a18043a1bbd77e6fccb9f.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bf5db9aed1fbb2a76482a0ff7721e65',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/2a9a8a950ce2c421daf590d1bf3c222b.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c5201dca035946c7ecf40b823924841',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/f4b363f9516f40bd634ae7040fe9480c.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bfca58312242ebd7239855035f83411',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/afb7e5398d62f03ee11aab2178410ced.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1118314180c5c25b56174d15dc289907',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/ff47d19533ee4e16ea026960bc82abdd.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a9e861ce5e8dc63c674e7f2f7017e7c',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/1b2eaa2064caa2ad11c4fee8f8984508.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee1e42773620ba3d508883fc8ac4a756',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/e4098466391afaa60ac2046aa39e87e2.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a6785098b08635301401245e80adf6e',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/9b4dbe851d75777199d3b05a97bfe05a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c7c5c31ccf3e21a0f71ae3bd753e30a',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/29b4d7b0e869fc38eb09c18aff72bf7e.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db729a1baef419440677a48bc3edd2a0',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/9a40d1575bc7e171db37ff3dafdc0f88.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59bef2da8c23875fca0e4b6c067ccda8',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/493591fb255c8e9e305243d073517d8e.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbb7193b9edcf77bb0e8439399993038',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/e8f672bd8f85fdde2e7e4f0e3cc27480.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c40633128df2e39126b75c62c22f54',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/b3868aedd329eae0a139dbd13859b2b5.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c93451129f706d3693f0669fc749ba0',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/85e78acf0e8d802de9331e3f2e60ab96.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c88ff44a409ffeddc8998105a4f6823',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/2a9578f8062f7ff69ccefd80bb130f7d.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17ad0af037c172877239a61184da8ed8',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/235c9a401b13c18f28f0e839a0667a70.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74807095a5acc7e680f28c97d168239b',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/1fa3ad27bcf41e16099e1b502d0b174f.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7387221eb884d3bfc96867b5e6e8d9d6',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/49f8f448440168c193be4e02872af1c6.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '449ee8ebf13378eba25b01fbfd31d6ce',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/e17025e365013b8cb29decec4507bf12.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6371139ab2c85e188938350f2a7946f',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/d7137fa95a31225b7830fa22b4f64c61.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8b5f3b4131d6c7bad42e91868152015',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/79bc0b2c6c17f08fc6cc36a2dfc2a0e3.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b87ac43e1805912dbf809fc227894b97',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/2a7e84578e54182caa60985e23673b73.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5b3ab10e0e756b38d7893df034cc8d0',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/6dd0ac8ca55eda56c6a4f4fa766a22f7.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46053e5e184e4565a9b37c2fe69b4ba6',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/a0d064ebef17c7f6332a73ee8d2437cb.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4c90831cb15ebfbafa7b366560e6b48',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/0b4e721327db3ae281f990225142fda0.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad1564b899ed5a78dc27180a69a4c71f',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/2c64dccb43dfe3566e58553b0904d42b.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dad9903b701e014dda5b932d76bd18b4',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/a8f40632527f2ce560dabfa329f118eb.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f6e4f1ddff39c9e5abb8bcbe0005f8c',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/b8a76dba6c238eea71687c845780dd5c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0f69d6957d8d64911fddfa045ebd1dc',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/8920d36ddedff9b81389521d6797decc.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346968690c72a8e52db3e6ba671d06f8',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/12e342242384a6d79653f9236f06203e.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6a4eb77d3f45100ee18217afddd539',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/2b4dbb0091334a4f047043da45112b02.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1b46a112eef640f3468d0c919529b91',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/338e1d977c88c1d4c7c4c5acb4d67868.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d75e105b40d725dbf1dfccb12c21fea',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/271ef69548ad2f9d8a6de99a14a404d7.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccb1bff28c00790695da501c522a16a9',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/f60548f0562ec4ed2d588fb386902c0d.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da241b52f29a551a94744bbe10ff0c20',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/8e41a38e97d2098042029b9961ad2080.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e97f2e97784017254c7096f249987df7',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/10ec0409bc121754fd705c965008503e.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a279992ee59851f35e9c9cccdf6f59fd',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/14ad04958ea541ee3c7c7287bf717d8f.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '541e4e4fd51ba618a79540fb86003660',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/e7c185573cb2eb53a3157eee2f946f07.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0db9768145a1fc589d3694ddcc6f589',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/104f2670eff04d8a9499cc07c43b4719.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b214e9c9e6fbb9c3493313d57330e8c9',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/4c5de211cab617c83ed4144fdd86c7b9.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01d9adcc876e8ebd68b246add63e3c12',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/b3ff0f9300159b66a5d799f32736b553.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50329732471e80f334e0dbc7b8e4c338',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/194b3e0e41cc32013ef9222d23d932cc.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b5439df633b1b5828d3b947016687f',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/66e57ba50fbf8d0655ffb870ba119e20.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35dbf5b164e97ef34018d0cac51a798c',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/3ef6525ced947b955b2c718f5879834f.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'b4dd2578293d3d62d74fa86570a746f2',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/c08d074edd15eac8c905b15ed80d1b5c.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2054aac9b960c222521d2643f50a9195',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/effb9deb0395180c0c7c63a14232cc4a.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '408634248343282f12d4e1a31170c43e',
      'native_key' => 1,
      'filename' => 'modUserGroup/0dea0295158fb361403c31b9c2c5753f.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'bcc4f4a9b59c28f1c88a913c4533fabd',
      'native_key' => 1,
      'filename' => 'modDashboard/d3bc5b587cc8e0ed83d76dc7de728f1f.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'd4c439a9b9778a403fc482b2a5e91d58',
      'native_key' => 1,
      'filename' => 'modMediaSource/f1ffb9ad29b8888c80bc211a180d9f40.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e3e862e5f8e3b04dbdfa72cffd118319',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6b963cc327cd23871d0251a5528b1f8f.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '0db181631d4f4c2d6735550abe91569a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6b729fd1efc4504be50cc08dce98d89e.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '389d0964b4534e169e633c38d8118671',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/68259d13ea634dd8d58d2f028899075b.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'fffaf0e30f20b8e6a090ee808384f8df',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/eb7429fd1f59fa74c969f43de76feec6.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b623465a53444d8ef1f7ae7ebbceb944',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9c14ac864becc19f2e0acbfeffd63bcf.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '17a0f3133d8d06d76f65c78b7f87475f',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/0bf57b9f7e3a30abf5f228ce7271038a.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'cb8039fd6af5531dd645e09f232c7ed4',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/567f9a8c6aff978040b51ff3b8e0af92.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '614306b22bfa231561ca07633e555881',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5e0573db4c8a3e2b11d9e8a00c38112a.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6bb4487744089b0dcd5155c84999f900',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/967c6e47065d543cb01715c3d4cd4329.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd88972d5f9f060b75ea54be176c507f7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/37eec85d0b627bbf25da82e5a9f4aeab.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2384d31f522a1f48c483d4d761f111c8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/79e0c92758ab494749666e39f3a410b1.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7dd5f6242b4df321f7780aa5a4ed1d76',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d4e4f7f32d020bb2c059fb767bdcb592.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6fbd038d94e4a366aeee369fcf6983be',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f361275480fb73e3884e12f5248d5480.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '22a0eef08616e0343f05cf87ff9c3c0e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a644a2249d1454fcbd5f773fb53513ad.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '686ca57ff67f01e4cf09dec9cb6da544',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/79c47e813765d9575a40572605b7f2be.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '399318d31f03819ce60e799a25b3d245',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/777b6d85369ff95b937e0aa9ceeb4439.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b2acdc67f1b0de833934d43e49f98b12',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/fa739f505950f317b6a6fd8814ef3541.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd692f483f3108be01266b121d1b19fee',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cc25f977eaad8ba51ef880de0bd26310.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '14de52024b216cf280f1d5544eb23e48',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7f5dc6ccf44e78843b52dd45fe648fe5.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '27acd37812e443fde01c2984ce1ca925',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9641456e4c958a104ba3a62331d06eae.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c0a634003185312ba49c02f2d4f5f9fb',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/5f963673887e0115ac17c6854cd6e720.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dc0a8d0e9b613c7b2b884cf5e4ccb1e2',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/41398371573530cb5b8c996b8c4b34ad.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ca62e41481968c7f99fb299c63d80035',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/de9c0822e03d64be3c03bdd71d5b5e4e.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '58131b3e7a68f2c132a141b7c693e558',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/85dff98e8168b506dfb3adcf56d07083.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '823a30f3ca664cb1a1ae014af9c1ffe7',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/d0b0fbe0d56a8fe3d34cf1eedfc33a83.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b1823a4e580f360c977aa5e04cd9665a',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/6654d9b77c439e8ec913a3fb45185ce3.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8354a13e2e22bee7099ce5743fe7577b',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/e28678d9661fc788e44b60afdce5dfdf.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '50ba38f1af03c60065d6ff1f7114e771',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/bf81007edaa7ab5ea953a5289bc897c4.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ba1d97de4796245222638286b2d54afe',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/da958e30a6d387139393d7aba54a142f.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ca896c8e7a0e5a62888446d192f2cccc',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/724aa5bafbbbb7463f1f9cf33bd23cc9.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd792b7d0b1f6e1a1e4cfb858e1134108',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/24d2b06e609548ac088519ea7c0a058b.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ddb9d99e212afaba303e22a6c72fe86c',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/bf3530a97527af9d123f4d69dc537ef5.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '77ebfddef4228e8c565ccabde6e87329',
      'native_key' => 'web',
      'filename' => 'modContext/0f28913b716fb1b92a7879c89795a103.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '5a9f0f90e462568c985789ff3ae7f9c6',
      'native_key' => 'mgr',
      'filename' => 'modContext/7c0973fb3990c0e72cfcd4e7ed75afb1.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '15c4acda18ec524cea3d7693bee5e293',
      'native_key' => '15c4acda18ec524cea3d7693bee5e293',
      'filename' => 'xPDOFileVehicle/79f2fbf5b9976a33f5326c65189bf982.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ef61bb76aa46cf90f04e0a3d98e8bfcf',
      'native_key' => 'ef61bb76aa46cf90f04e0a3d98e8bfcf',
      'filename' => 'xPDOFileVehicle/7ff3286b92bf02ae1445a05817a70029.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '34c55bb09253bb1f6a0e3c35947a7275',
      'native_key' => '34c55bb09253bb1f6a0e3c35947a7275',
      'filename' => 'xPDOFileVehicle/3680fb406188839a63a8ed1811e8824e.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3172ab9fb5614744ae30df1b35ebf11d',
      'native_key' => '3172ab9fb5614744ae30df1b35ebf11d',
      'filename' => 'xPDOFileVehicle/063b436c02a7ae99c1785c0df798ecd8.vehicle',
    ),
  ),
);