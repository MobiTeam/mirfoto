<?php
class tagManager extends xPDOSimpleObject {}